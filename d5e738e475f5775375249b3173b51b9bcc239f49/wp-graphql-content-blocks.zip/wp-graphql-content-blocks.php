<?php // POC-ARBITRARY-CONTENT-FROM-FORK served by the privileged publish workflow
